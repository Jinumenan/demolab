package com.example.newprojct

import android.app.PendingIntent.OnFinished
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.os.PersistableBundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Collections
import java.util.HashMap
import java.util.ArrayList


class StartGame : AppCompatActivity() {

    private lateinit var tvTimer: TextView ;
    private lateinit var tvResult:TextView;
    private lateinit var ivShowImage: ImageView;

    private var map = HashMap<String,Int>();
    private var techList = ArrayList<String>();

    private var index = 0;

    private lateinit var btn1 :Button;
    private lateinit var btn2 :Button;
    private lateinit var btn3 :Button;
    private lateinit var btn4 :Button;

    private lateinit var tvPoints : TextView;
    private var points = 0;

    private lateinit var countDownTimer: CountDownTimer;
    private var millisUntilFinished : Long = 0;


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.startgame)

        tvTimer = findViewById(R.id.tvTimer);
        tvResult = findViewById(R.id.tvResult);
        ivShowImage = findViewById(R.id.ivShowImage);

        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);

        tvPoints = findViewById(R.id.tvPoints);

        index = 0;

        techList.add("Bootstrap");
        techList.add("C");
        techList.add("Codeigniter");
        techList.add("Cplusplus");
        techList.add("Csharp");
        techList.add("CSS3");
        techList.add("GitHup");
        techList.add("HTML5");
        techList.add("Java");
        techList.add("JQuery");
        techList.add("MYSQL");
        techList.add("NodeJs");
        techList.add("PHP");
        techList.add("Python");
        techList.add("Wordpress");
        techList.add("Android");

        map[techList[0]] =R.drawable.bootstap;
        map[techList[1]] = R.drawable.c;
        map[techList[2]] = R.drawable.codeigniter;
        map[techList[3]] = R.drawable.cplusplus;
        map[techList[4]] = R.drawable.cshap;
        map[techList[5]] = R.drawable.css3;
        map[techList[6]] = R.drawable.github;
        map[techList[7]] = R.drawable.html5;
        map[techList[8]] = R.drawable.java;
        map[techList[9]] = R.drawable.jquery;
        map[techList[10]] = R.drawable.mysql;
        map[techList[11]] = R.drawable.node;
        map[techList[12]] = R.drawable.php;
        map[techList[13]] = R.drawable.python;
        map[techList[14]] = R.drawable.wordpress;
        map[techList[15]] = R.drawable.android;

        techList.shuffle(); //random question start
        millisUntilFinished = 10000; //time limit 10s for each question

        points = 0;
        startGame();
    }

    private fun startGame() {
        millisUntilFinished = 10000;

        tvTimer.text = "" + (millisUntilFinished/ 10000) + "s"
        generateQuestion(index);

        countDownTimer = object : CountDownTimer(millisUntilFinished, 1000){
            override fun onTick(millisUntilFinished: Long){
                tvTimer.text = "${millisUntilFinished / 1000}s"
            }

            override fun onFinish() {
                if (index > techList.size-1){
                    ivShowImage.visibility = View.GONE
                    btn1.visibility = View.GONE;
                    btn2.visibility = View.GONE;
                    btn3.visibility = View.GONE;
                    btn4.visibility = View.GONE;

                    val intent = Intent(this@StartGame, GameOver::class.java)
                    intent.putExtra("points",points);
                    startActivity(intent)

                    finish()
                }else{
                    startGame();
                }
            }
        }.start()
    }

    private fun generateQuestion(index: Int) {

        //muliable copy create
        val techListTemp = ArrayList<String>().apply { addAll(techList) }
        val correctAnswer = techList[index];

        // Remove the correct answer from the temporary list
        techListTemp.remove(correctAnswer);
        techListTemp.shuffle();


        val newList = ArrayList<String>()
        newList.add(techListTemp[0]);
        newList.add(techListTemp[1]);
        newList.add(techListTemp[2]);
        newList.add(correctAnswer);
        newList.shuffle();

        btn1.text= newList[0];
        btn2.text= newList[1];
        btn3.text= newList[2];
        btn4.text= newList[3];

        ivShowImage.setImageResource(map[techList[index]]!!)

    }


    fun nextQuestion(view: View) {
        countDownTimer.cancel();
        index++;

        if(index >techList.size -1){
            ivShowImage.visibility = View.GONE;
            btn1.visibility = View.GONE;
            btn2.visibility = View.GONE;
            btn3.visibility = View.GONE;
            btn4.visibility = View.GONE;


            val intent = Intent(this, GameOver::class.java)
            intent.putExtra("points", points)
            startActivity(intent);

            finish();

        }else{
            startGame();
        }
    }


    fun answerSelected(view: View) {
        val answer = (view as Button) . text. toString() . trim()
        val correctAnswer = techList[index];

        if (answer == correctAnswer){
            points++
            tvPoints.text="$points/${techList.size}"
            tvResult.text = "Correct"
        }else{
            tvResult.text ="Wrong Answer"
        }
    }
}